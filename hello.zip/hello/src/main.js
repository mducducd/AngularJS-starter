console.log('main file');
var nameCardModule = require('./name-card');
angular.module('helloApp', [nameCardModule])
    .controller('aController', function($scope) {
        $scope.name = "Duc";
    });
