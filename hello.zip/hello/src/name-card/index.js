const moduleName = "nameCard";
module.exports = moduleName;

angular.module(moduleName, []).component(moduleName, {
    template: require('./template.html'),
    controller: nameCardController
});

function nameCardController($scope) {
    console.log("this is name card");
    $scope.name = "Duc";
}
